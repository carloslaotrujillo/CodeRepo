# SmartBrain-api - v1
Final project for ZTM course

1. Clone this repo
2. Run `npm install`
3. Run `npm start`
4. Enter the details for your own databse in `server.js`

** Make sure you use postgreSQL instead of mySQL for this code base.

*visist https://zerotomastery.io/ for more*
