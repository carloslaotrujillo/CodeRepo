import React from 'react'
import './styles.css'

const Post = () => {
  return (
  <React.Fragment>
     <ul className="cards" >
      </ul>
  </React.Fragment>
  );
}

export default Post;
