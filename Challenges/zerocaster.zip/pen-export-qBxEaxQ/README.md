# Zerocater Frontend Take Home Exam

A Pen created on CodePen.io. Original URL: [https://codepen.io/krloslao90/pen/qBxEaxQ](https://codepen.io/krloslao90/pen/qBxEaxQ).

